import torch
import argparse
import datetime
import math
import os
import random
import numpy as np
import torch.nn.functional as F
import torch.optim as optim
from torch import nn
from torch.utils.data import DataLoader
from torchvision import transforms
from matplotlib import pyplot as plt
from torch.optim.lr_scheduler import StepLR

from util import dataset, transform, config
from util.util import check_makedirs
import pytorch_iou
from model.model import HFCNet

eps = math.exp(-10)


def createModel(args):
    net = HFCNet(args)
    return net


# ---------------------- 参数解析 ----------------------
def get_parser():
    parser = argparse.ArgumentParser(description='PyTorch Semantic Segmentation')
    parser.add_argument('--config', type=str, default='config/dataset_e.yaml', help='config file')
    parser.add_argument('--device', type=str, default='cuda:0')
    parser.add_argument('--model_id', type=str, default='HFCNet')
    parser.add_argument('--flag', type=str, default='test')
    parser.add_argument('--epochs', nargs='+', type=int, default=[40],
                        help='List of epochs to test, e.g. --epochs 33 34 40')
    parser.add_argument('opts', help='see config/*.yaml for options', default=None, nargs=argparse.REMAINDER)

    args = parser.parse_args()
    assert args.config is not None
    cfg = config.load_cfg_from_cfg_file(args.config)
    if args.opts is not None:
        cfg = config.merge_cfg_from_list(cfg, args.opts)
    return cfg, args


# ---------------------- 工具函数 ----------------------
def MaxMinNormalization(x):
    Max = torch.max(x)
    Min = torch.min(x)
    x = torch.div(torch.sub(x, Min), 0.0001 + torch.sub(Max, Min))
    return x


def loss_curve(counter, losses):
    fig = plt.figure()
    plt.plot(counter, losses, color='blue')
    plt.legend(['Train Loss'], loc='upper right')
    plt.xlabel('Iteration')
    plt.ylabel('Loss')
    plt.show()

# ---------------------- 自定义Loss ----------------------
class MyLoss:
    def __init__(self):
        self.IOU = pytorch_iou.IOU(size_average=True)
        self.eps = 1e-8

    def loss(self, X, y, pc_map1):
        lossAll = 0
        for i, x in enumerate(X):
            if x.dim() != 4:
                x = x.unsqueeze(1)
            if y.dim() == 3:
                y = y.unsqueeze(1)

            ce_loss = (-y * torch.log(x + self.eps) - (1 - y) * torch.log(1 - x + self.eps)).sum()
            num_pixel = y.numel()
            base_ce = ce_loss / num_pixel
            base_iou = self.IOU(x, y)

            if i in [0, 1]:
                target_size = x.shape[2:]
                pc_map = F.interpolate(pc_map1, size=target_size, mode='bilinear', align_corners=False)
                if pc_map.shape[1] != 1:
                    pc_map = pc_map.mean(dim=1, keepdim=True)
                pc_weight = (pc_map - pc_map.min()) / (pc_map.max() - pc_map.min() + self.eps)
                weighted_ce = ((-y * torch.log(x + self.eps) - (1 - y) * torch.log(1 - x + self.eps))
                               * pc_weight).sum() / num_pixel
                weighted_iou = self.IOU(x * pc_weight, y * pc_weight)
                lossAll += weighted_ce + weighted_iou
            else:
                lossAll += base_ce + base_iou
        return lossAll
# ---------------------- 训练部分 ----------------------

def train(loss_fn, args, arg):
    dev = arg.device
    model_id = arg.model_id
    train_losses = []
    train_counter = []

    value_scale = 255
    mean = [0.485, 0.456, 0.406]
    mean = [item * value_scale for item in mean]
    std = [0.229, 0.224, 0.225]
    std = [item * value_scale for item in std]

    train_transform = transform.Compose([
        transform.Resize((args.img_h, args.img_w)),
        transform.RandRotate([args.rotate_min, args.rotate_max], padding=mean, ignore_label=args.ignore_label),
        transform.RandomGaussianBlur(),
        transform.RandomHorizontalFlip(),
        transform.RandomVerticalFlip(),
        transform.ToTensor(),
        transform.Normalize(mean=mean, std=std)
    ])

    dataset_root = args.data_root
    if args.data_name == 'ORSSD':
        train_data = dataset.ORSSD(dataset_root, 'train', transform=train_transform)
    elif args.data_name == 'EORSSD':
        train_data = dataset.EORSSD(dataset_root, 'train', transform=train_transform)
    elif args.data_name == 'ORSI':
        train_data = dataset.EORSSD(dataset_root, 'train', transform=train_transform)
    else:
        raise ValueError(f"Unsupported dataset: {args.data_name}")

    train_loader = DataLoader(train_data, batch_size=args.train_batch_size, shuffle=True, num_workers=8, pin_memory=True)
    net = createModel(args)
    device = torch.device(dev if torch.cuda.is_available() else 'cpu')
    model = net.to(device)

    optimizer = optim.Adam(model.parameters(), lr=0.00007, betas=(0.9, 0.999))
    scheduler = StepLR(optimizer, step_size=20, gamma=0.5)
    start_epoch = 0

    if args.resume:
        checkpoint = torch.load(args.resume, map_location='cpu')
        model.load_state_dict(checkpoint['model'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        scheduler.load_state_dict(checkpoint['lr_scheduler'])
        start_epoch = checkpoint['epoch'] + 1

    date_str = str(datetime.datetime.now().date())
    model.train()
    lossAvg = 0
    interNum = 10

    for epoch in range(start_epoch, args.epoch_num):
        for i, (input, gt, _) in enumerate(train_loader):
            input, gt = input.to(device), gt.to(device)
            optimizer.zero_grad()
            outs, pc_map1 = model(input)
            gt = MaxMinNormalization(gt)
            loss = loss_fn.loss(outs, gt, pc_map1)
            loss.backward()
            optimizer.step()
            lossAvg += loss.item()
            train_losses.append(loss.item())
            train_counter.append(((epoch) * len(train_data) / args.train_batch_size) + i)

            if ((i + 1) % interNum == 0) or (i + 1 == len(train_loader)):
                print(f'Train Epoch: {epoch + 1} [{(i + 1) * len(input)}/{len(train_data)} '
                      f'({100. * (i + 1) * args.train_batch_size / len(train_data):.0f}%)] '
                      f'Loss: {lossAvg / interNum:.10f}')
                lossAvg = 0

        scheduler.step()
        print(f"第{epoch + 1}个epoch的学习率：{optimizer.param_groups[0]['lr']}")
        model_folder = args.model_path + date_str + '/'
        check_makedirs(model_folder)
        save_file = {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "lr_scheduler": scheduler.state_dict(),
            "epoch": epoch,
            "args": args
        }
        torch.save(save_file, model_folder + f'{model_id}_{epoch + 1}.pth')

    loss_curve(train_counter, train_losses)


def test(args, arg):
    # 测试数据转换及数据载入
    dev = arg.device
    model_id = arg.model_id
    value_scale = 255
    mean = [0.485, 0.456, 0.406]
    mean = [item * value_scale for item in mean]
    std = [0.229, 0.224, 0.225]
    std = [item * value_scale for item in std]
    test_transform = transform.Compose([
        transform.Resize((args.img_h, args.img_w)),
        transform.ToTensor(),
        transform.Normalize(mean=mean, std=std)])
    to_pil_img = transforms.ToPILImage()  # 将输出的tensor转换为PIL image

    date_str = str(datetime.datetime.now().date())  # 获取当前时间的日期
    results_folder = args.results_folder + date_str  # '2024-08-01/'  # 以当前日期命名文件夹

    if args.data_name == 'ORSSD':
        test_data = dataset.ORSSD(args.data_root, 'test', transform=test_transform)
    elif args.data_name == 'EORSSD':
        test_data = dataset.EORSSD(args.data_root, 'test', transform=test_transform)
    elif args.data_name == 'ORSI':
        test_data = dataset.EORSSD(args.data_root, 'test', transform=test_transform)
    else:
        test_data = None
    img_path_list = test_data.image_paths
    img_name_list = []
    n_imgs = len(test_data)
    for i in range(n_imgs):
        img_name = img_path_list[i].split('/')[
            -1]  # img_path_list[i][0] is the image path, img_path_list[i][1] is the train-labels path
        img_name_list.append(img_name)

    test_sampler = None
    test_loader = DataLoader(test_data, batch_size=args.test_batch_size,
                             shuffle=False,
                             num_workers=args.workers,
                             pin_memory=True,
                             sampler=test_sampler,
                             drop_last=True)

    epoch_list = [
        40
    ]
    for now in epoch_list:
        net = createModel(args)
        device = torch.device(dev if torch.cuda.is_available() else 'cpu')
        model = net.to(device)
        model_dir = r"C:\Users\Administrator\Downloads\HFCNet_805.pth"# the path/file to save the trained model params.
        results_folder_now = results_folder + "/" + '' + model_id + '_' + str(now)
        model.load_state_dict(torch.load(model_dir)['model'])
        print('The network parameters are loaded!')


        model.eval()
        for i, (input, _, img_size) in enumerate(test_loader):
            input = input.to(device)
            outs, _ = model(input)
            sal1 = outs[0]
            n_img, _, _ = sal1.size()

            for j in range(n_img):
                salmaps = to_pil_img(sal1[j].cpu())
                salmaps = salmaps.resize((int(img_size[j][1]), int(img_size[j][0])))

                file_name = img_name_list[i * args.test_batch_size + j]
                # 只保留文件名（去除路径前缀）
                file_name = os.path.basename(file_name)  # 关键修改

                # 确保结果目录存在
                if not os.path.exists(results_folder_now):
                    os.makedirs(results_folder_now, exist_ok=True)

                # 使用 os.path.join() 拼接路径
                save_path = os.path.join(results_folder_now, file_name)
                print(f"保存路径: {save_path}")

                try:
                    salmaps.save(save_path)
                    print(f"成功保存: {save_path}")
                except Exception as e:
                    print(f"保存失败: {save_path}")
                    print(f"错误信息: {str(e)}")

                print(f'Testing {i * args.test_batch_size + j} th image')


if __name__ == '__main__':

    args, arg = get_parser()
    Flag_train_test = arg.flag

    print(Flag_train_test)
    if Flag_train_test == 'train':
        criterion = MyLoss()
        train(loss_fn=criterion, args=args, arg=arg)
    else:
        ##########################################################################################
        # to test the network.
        test(args=args, arg=arg)


