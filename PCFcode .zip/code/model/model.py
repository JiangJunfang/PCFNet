from tkinter.tix import Tree
import numpy as np
import math
import torch
from torch import nn
import torch.nn.functional as F
from matplotlib import pyplot as plt
import math
# import scipy.stats
from torch.utils.data import Dataset
import cv2
# from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from swintransformer.backbone import SwinTransformer
from typing import Any, Optional, Tuple, Type
from torch.fft import fft2
from model.DRF import DRM


def segm_swin(pretrained, args):
    if args.swin_type == 'tiny':
        embed_dim = 96
        depths = [2, 2, 6, 2]
        num_heads = [3, 6, 12, 24]
    elif args.swin_type == 'small':
        embed_dim = 96
        depths = [2, 2, 18, 2]
        num_heads = [3, 6, 12, 24]
    elif args.swin_type == 'base':
        embed_dim = 128
        depths = [2, 2, 18, 2]
        num_heads = [4, 8, 16, 32]
    elif args.swin_type == 'large':
        embed_dim = 192
        depths = [2, 2, 18, 2]
        num_heads = [6, 12, 24, 48]
    else:
        assert False
    if 'window12' in pretrained:
        print('Window size 12!')
        window_size = 12
    else:
        window_size = 7
    mha = [1, 1, 1, 1]
    out_indices = (0, 1, 2, 3)
    backbone = SwinTransformer(embed_dim=embed_dim, depths=depths, num_heads=num_heads,
                               window_size=window_size,
                               ape=False, drop_path_rate=0.3, patch_norm=True,
                               out_indices=out_indices,
                               use_checkpoint=False, num_heads_fusion=mha,
                               fusion_drop=0.0, frozen_stages=-1
                               )
    if pretrained:
        print('Initializing Swin Transformer weights from ' + pretrained)
        backbone.init_weights(pretrained=pretrained)
    else:
        print('Randomly initialize Swin Transformer weights.')
        backbone.init_weights()
    return backbone


class PhaseCongruencyEnhancer(nn.Module):
    def __init__(self, in_channels, num_orientations=6, num_scales=1, reduce_ratio=4):
        super().__init__()
        self.in_channels = in_channels
        self.num_orientations = num_orientations
        self.num_scales = num_scales
        self.eps = 1e-8

        # 单尺度参数设置
        self.sigma_base = 2.4
        self.scale_factor = 2.2
        self.wavelength_min = 8

        self.reduced_channels = in_channels // reduce_ratio

        # 通道缩减与恢复模块
        self.reduce_channels = nn.Conv2d(
            in_channels,
            self.reduced_channels,
            kernel_size=1,
            stride=1,
            padding=0
        )
        self.restore_channels = nn.Sequential(
            nn.Conv2d(self.reduced_channels, in_channels, kernel_size=1),
            nn.Sigmoid()
        )

        # 单尺度LogGabor滤波器组
        self.loggabor_groups = nn.ModuleList(
            self._create_loggabor_groups(reduced_channels=self.reduced_channels)
        )

        # 条纹检测器（保留）
        self.stripe_detector = nn.Conv2d(
            in_channels=self.reduced_channels,
            out_channels=self.reduced_channels,
            kernel_size=7,
            padding=3,
            groups=self.reduced_channels,
            bias=False
        )
        nn.init.xavier_normal_(self.stripe_detector.weight)

        # 单尺度权重
        self.register_buffer("W", torch.tensor([0.5]).view(1, 1, 1, 1))

        # 空间注意力模块
        self.spatial_att = nn.Conv2d(2, 1, kernel_size=7, padding=3, bias=False)
        self.pc_norm = nn.LayerNorm(self.reduced_channels)

        # DoG滤波器参数（高斯差分）
        self.dog_sigma1 = 1.0
        self.dog_sigma2 = 2.0
        self.dog_kernel = self._create_dog_kernel()
        self.dog_conv = nn.Conv2d(
            in_channels=self.reduced_channels,
            out_channels=self.reduced_channels,
            kernel_size=self.dog_kernel.shape[-1],
            padding=self.dog_kernel.shape[-1] // 2,
            groups=self.reduced_channels,
            bias=False
        )
        self.dog_conv.weight.data = self.dog_kernel.repeat(self.reduced_channels, 1, 1, 1)
        self.dog_conv.weight.requires_grad = False

    # 以下方法（_create_dog_kernel, _create_loggabor_groups, _loggabor_kernel）与原版本一致
    def _create_dog_kernel(self, kernel_size=None):
        if kernel_size is None:
            kernel_size = int(2 * max(3 * self.dog_sigma2, 3) + 1)
            if kernel_size % 2 == 0:
                kernel_size += 1
        x = np.arange(-kernel_size // 2 + 1, kernel_size // 2 + 1)
        y = np.arange(-kernel_size // 2 + 1, kernel_size // 2 + 1)
        xx, yy = np.meshgrid(x, y)
        g1 = np.exp(-(xx **2 + yy** 2) / (2 * self.dog_sigma1 **2))
        g2 = np.exp(-(xx** 2 + yy **2) / (2 * self.dog_sigma2** 2))
        dog = g1 - g2
        dog = dog / np.max(np.abs(dog))
        return torch.FloatTensor(dog).unsqueeze(0).unsqueeze(0)

    def _create_loggabor_groups(self, reduced_channels):
        groups = []
        sigma_list = [2.0, 2.8]
        wavelength_list = [8, 12]
        for sigma, wavelength in zip(sigma_list, wavelength_list):
            kernel_size = int(round(wavelength * 3.5))
            if kernel_size % 2 == 0:
                kernel_size += 1
            padding = (kernel_size - 1) // 2
            theta = 0
            kernel = self._loggabor_kernel(kernel_size, sigma, theta, wavelength)
            kernel = torch.FloatTensor(kernel).unsqueeze(0).unsqueeze(0)
            kernel = kernel.repeat(self.num_orientations, 1, 1, 1)
            kernel = kernel.repeat_interleave(reduced_channels, dim=0)
            conv = nn.Conv2d(
                in_channels=reduced_channels,
                out_channels=reduced_channels * self.num_orientations,
                kernel_size=kernel_size,
                padding=padding,
                groups=reduced_channels,
                bias=False
            )
            conv.weight.data = kernel
            groups.append(conv)
        return groups

    def _loggabor_kernel(self, kernel_size, sigma, theta, wavelength):
        x, y = np.meshgrid(
            np.arange(-kernel_size // 2 + 1, kernel_size // 2 + 1),
            np.arange(-kernel_size // 2 + 1, kernel_size // 2 + 1)
        )
        x_rot = x * np.cos(theta) + y * np.sin(theta)
        y_rot = -x * np.sin(theta) + y * np.cos(theta)
        omega0 = 2 * np.pi / wavelength
        omega = np.sqrt(x_rot **2 + y_rot** 2 + self.eps)
        radial = np.exp(-(np.log(omega / omega0)) **2 / (2 * (np.log(self.scale_factor))** 2))
        angular = np.exp(-(y_rot **2) / (2 * sigma** 2))
        kernel = radial * angular * np.cos(omega0 * x_rot)
        kernel = kernel / np.sum(np.abs(kernel))
        return kernel

    def forward(self, x):
        b, c, h, w = x.shape
        if torch.isnan(x).any():
            print("Input x has nan!")
            return x

        # 1. 通道缩减
        x_reduced = self.reduce_channels(x)
        if torch.isnan(x_reduced).any():
            print("x_reduced has nan after reduce_channels!")

        # 2. 应用DoG滤波器增强边缘和纹理
        x_dog = self.dog_conv(x_reduced)
        x_enhanced = x_reduced + 0.5 * x_dog

        # 3. 相位一致性计算（保留条纹检测器）
        pc_list = []
        filtered_list = []
        for conv_layer in self.loggabor_groups:
            filtered = conv_layer(x_enhanced)
            filtered_list.append(filtered)
        filtered = torch.mean(torch.stack(filtered_list, dim=1), dim=1)
        filtered = filtered.view(b, self.reduced_channels, self.num_orientations, h, w)
        amp = torch.abs(filtered)
        phase = torch.angle(torch.complex(filtered, torch.zeros_like(filtered)))

        W = self.W[:, 0:1]
        amp_weighted = amp * W
        amp_sum_scale = amp_weighted.sum(dim=2, keepdim=True) + self.eps
        mean_phase_scale = (amp_weighted * phase).sum(dim=2, keepdim=True) / amp_sum_scale
        phase_diff = phase - mean_phase_scale
        delta_phi = torch.cos(phase_diff) - torch.abs(torch.sin(phase_diff))
        local_amp_mean = F.avg_pool2d(amp_weighted.mean(dim=2), 3, padding=1, stride=1)
        T = 0.5 * local_amp_mean.unsqueeze(2)

        valid_term = torch.clamp(amp_weighted * (delta_phi - T), min=0)
        valid_sum = valid_term.sum(dim=2)
        scale_valid = valid_sum
        amp_sum = amp_sum_scale.squeeze(2)
        pc = scale_valid / (amp_sum + self.eps)

        # 条纹检测器操作（保留）
        stripe_response = self.stripe_detector(pc)
        stripe_mask = torch.sigmoid(-stripe_response * 5)
        pc = pc * stripe_mask
        pc_list.append(pc)

        # 后续处理保持不变
        pc_map_reduced = pc_list[0].clone()
        pc_map_reduced = pc_map_reduced.permute(0, 2, 3, 1)
        pc_map_reduced = self.pc_norm(pc_map_reduced)
        pc_map_reduced = pc_map_reduced.permute(0, 3, 1, 2)
        pc_map_reduced = torch.clamp(pc_map_reduced, min=-3, max=3)

        # 空间注意力增强
        x_mean = torch.mean(x, dim=1, keepdim=True)
        x_var = torch.var(x, dim=1, keepdim=True)
        spatial_att = self.spatial_att(torch.cat([x_mean, x_var], dim=1))
        spatial_att = torch.sigmoid(spatial_att)

        pc_map = self.restore_channels(pc_map_reduced)
        enhanced = x * (1 + pc_map * spatial_att)
        if torch.isnan(enhanced).any():
            print("Enhanced output has nan!")
        return enhanced, pc_map



class HFCNet(nn.Module):
    def __init__(self, args):
        super(HFCNet, self).__init__()
        # 原有层定义...
        self.upsample32 = nn.Upsample(scale_factor=32, mode='bilinear', align_corners=True)
        self.upsample16 = nn.Upsample(scale_factor=16, mode='bilinear', align_corners=True)
        self.upsample8 = nn.Upsample(scale_factor=8, mode='bilinear', align_corners=True)
        self.upsample4 = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.downsample2 = nn.Upsample(scale_factor=0.5, mode='bilinear', align_corners=True)
        self.sig = nn.Sigmoid()

        self.swin = segm_swin(args.pretrained, args)
        self.decoder = SGAED()
        self.pos = PositionEmbeddingRandom(64, 1.0)
        # 在HFCNet的__init__中修改
        self.p1 = PhaseCongruencyEnhancer(128, reduce_ratio=4)  # 128→32通道
        self.phase_weight = nn.Parameter(torch.tensor(0.5))

        # self.conv1 = nn.Sequential(BasicConv2d(1536, 256, 3, padding=1), BasicConv2d(256, 256, 3, padding=1))
        # self.conv2 = nn.Sequential(BasicConv2d(512 + 256, 256, 3, padding=1), BasicConv2d(256, 256, 3, padding=1))
        # self.conv3 = nn.Sequential(BasicConv2d(256 + 128, 256, 3, padding=1), BasicConv2d(256, 256, 3, padding=1))

        self.merge1 = DRM(in_channels_B=1024, in_channels_T=512, channel=256, layers=5)
        self.merge2 = DRM(in_channels_B=512, in_channels_T=256, channel=256, layers=5)
        self.merge3 = DRM(in_channels_B=256, in_channels_T=128, channel=256, layers=5)

    def forward(self, Xin):
        x1 = self.swin(Xin, 0, 0)
        x1_enhanced, pc_map1 = self.p1(x1)
        x1_fused = x1 + self.phase_weight * x1_enhanced

        xs2 = self.swin(x1, 0, 1)
        x2 = self.swin(xs2, 1, 0)
        x2 = F.interpolate(x2, size=(56, 56), mode='bilinear', align_corners=False)
        xs3 = self.swin(x2, 1, 1)
        x3 = self.swin(xs3, 2, 0)
        x3 = F.interpolate(x3, size=(28, 28), mode='bilinear', align_corners=False)
        xs4 = self.swin(x3, 2, 1)
        x4 = self.swin(xs4, 3, 0)
        x4 = F.interpolate(x4, size=(14, 14), mode='bilinear', align_corners=False)
        # breakpoint()

        x3_down = F.interpolate(x3, size=(14, 14), mode='bilinear', align_corners=False)
        # x4_opt = self.conv1(torch.cat((x4, x3_down), dim=1)(1024,512)
        x4_opt = self.merge1(x4, x3_down)

        x2_down = F.interpolate(x2, size=(28, 28), mode='bilinear', align_corners=False)
        # x3_opt = self.conv2(torch.cat((x3, x2_down), dim=1))
        x3_opt = self.merge2(x3, x2_down)

        x1_down = F.interpolate(x1_fused, size=(56, 56), mode='bilinear', align_corners=False)
        # x2_opt = self.conv3(torch.cat((x2, x1_down), dim=1))
        x2_opt = self.merge3(x2, x1_down)

        # 3. 解码器输出（使用加权后的特征）
        s1, s2, s3, s4, s5, s6 = self.decoder(x4_opt, x4_opt, x3_opt, x2_opt, x1_fused)
        s1 = self.sig(s1.squeeze(dim=1))
        s2 = self.sig(s2.squeeze(dim=1))
        s3 = self.sig(s3.squeeze(dim=1))
        s4 = self.sig(s4.squeeze(dim=1))
        s5 = self.sig(s5.squeeze(dim=1))
        s6 = self.sig(s6.squeeze(dim=1))

        outs = [s1, s2, s3, s4, s5, s6]
        return outs, pc_map1


# SGAED解码器
class SGAED(nn.Module):
    def __init__(self):
        super(SGAED, self).__init__()

        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)  # 2倍上采样
        self.upsample4 = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)  # 4倍上采样（缺失的层）
        self.upsample8 = nn.Upsample(scale_factor=8, mode='bilinear', align_corners=True)  # 8倍上采样
        self.upsample16 = nn.Upsample(scale_factor=16, mode='bilinear', align_corners=True)  # 16倍上采样
        # self.downsample16 = nn.Upsample(scale_factor=0.0625, mode='bilinear', align_corners=True)
        # self.downsample8 = nn.Upsample(scale_factor=0.125, mode='bilinear', align_corners=True)
        # self.downsample4 = nn.Upsample(scale_factor=0.25, mode='bilinear', align_corners=True)
        # self.downsample2 = nn.Upsample(scale_factor=0.5, mode='bilinear', align_corners=True)

        self.decoder6 = CalculateUnitAE(256, 0, 256, 256)
        self.S6 = nn.Conv2d(256, 1, 3, stride=1, padding=1)  # 输入256 → 输出1

        self.decoder5 = CalculateUnitAE(256, 256, 512, 256)
        self.S5 = nn.Conv2d(256, 1, 3, stride=1, padding=1)  # 输入256 → 输出1

        self.decoder4 = CalculateUnitAE(256, 256, 256, 256)
        self.S4 = nn.Conv2d(256, 1, 3, stride=1, padding=1)  # 输入256 → 输出1

        self.decoder3 = CalculateUnitAE(256, 256, 256, 256)
        self.S3 = nn.Conv2d(256, 1, 3, stride=1, padding=1)  # 输入256 → 输出1

        self.decoder2 = CalculateUnitAE(128, 256, 128, 128)
        self.S2 = nn.Conv2d(128, 1, 3, stride=1, padding=1)  # 输入128 → 输出1

        self.decoder1 = CalculateUnitAE(128, 128, 64, 64)
        self.S1 = nn.Conv2d(64, 1, 3, stride=1, padding=1)  # 输入64 →

    def forward(self, x_l, x4, x3, x2, x1_fused):
        x6 = self.decoder6(x_l, 0, 0) + x_l
        s6 = self.S6(x6)

        x6_down = F.interpolate(x6, size=x4.shape[2:], mode='bilinear', align_corners=False)
        s6_down = F.interpolate(s6, size=x4.shape[2:], mode='bilinear', align_corners=False)

        x5 = self.decoder5(x4, x6_down, s6_down)
        x5_up = self.upsample2(x5)
        s5 = self.S5(x5)

        x4_dec = self.decoder4(x3, x5_up, self.upsample2(s5))
        x4_up = self.upsample2(x4_dec)
        s4 = self.S4(x4_dec)

        x3_dec = self.decoder3(x2, x4_up, self.upsample2(s4))
        x3_up = self.upsample2(x3_dec)
        s3 = self.S3(x3_dec)

        x2_dec = self.decoder2(x1_fused, x3_up, self.upsample2(s3))
        x2_up = self.upsample2(x2_dec)  # 此时x2_up尺寸为112×112
        s2 = self.S2(x2_dec)
        x2_up_down = F.interpolate(x2_up, size=x2_dec.shape[2:], mode='bilinear', align_corners=False)
        # 使用下采样后的x2_up_down作为decoder1的输入
        x1_dec = self.decoder1(x2_dec, x2_up_down, self.upsample2(s2))
        s1 = self.S1(x1_dec)  # 112×112
        s2 = self.S2(x2_dec)  # 112×112
        s3 = self.S3(x3_dec)  # 56×56
        s4 = self.S4(x4_dec)  # 28×28
        s5 = self.S5(x5)  # 14×14
        s6 = self.S6(x6)  # 14×14

        # 关键修改：按所需倍数上采样至224×224
        s1 = self.upsample2(s1)  # 112×2 → 224
        s2 = self.upsample2(s2)  # 112×2 → 224
        s3 = self.upsample4(s3)  # 56×4 → 224
        s4 = self.upsample8(s4)  # 28×8 → 224
        s5 = self.upsample16(s5)  # 14×16 → 224
        s6 = self.upsample16(s6)  # 14×16 → 224

        return s1, s2, s3, s4, s5, s6


class CalculateUnitAE(nn.Module):
    def __init__(self, in_Channel1=0, in_Channel2=0, mid_Channel3=0, out_Channel=0):
        super(CalculateUnitAE, self).__init__()
        self.sig = nn.Sigmoid()
        self.AE1 = AE(in_Channel1) if in_Channel1 > 0 else None
        self.AE2 = AE(in_Channel2) if in_Channel2 > 0 else None
        # 新增：为inSA添加通道适配卷积（将1通道转为与in1/in2匹配的通道数）
        self.sa_adapt1 = nn.Conv2d(1, in_Channel1, kernel_size=1, bias=False) if in_Channel1 > 0 else None
        self.sa_adapt2 = nn.Conv2d(1, in_Channel2, kernel_size=1, bias=False) if in_Channel2 > 0 else None
        self.conv = nn.Sequential(
            BasicConv2d(in_Channel1 + in_Channel2, mid_Channel3, 3, padding=1),
            BasicConv2d(mid_Channel3, out_Channel, 3, padding=1)
        )

    def forward(self, in1, in2=0, inSA=0):
        SA1 = 0
        SA2 = 0
        if torch.is_tensor(inSA):
            SA = self.sig(inSA)
            if self.sa_adapt1 is not None:
                SA1 = self.sa_adapt1(SA)
            if self.sa_adapt2 is not None and torch.is_tensor(in2):
                SA2 = self.sa_adapt2(SA)

        # 仅在 AE1 存在时调用
        x = self.AE1(in1, SA1) if self.AE1 is not None else in1
        # 仅在 AE2 存在且 in2 是张量时处理
        if self.AE2 is not None and torch.is_tensor(in2):
            in2 = self.AE2(in2, SA2)
            x = torch.cat([x, in2], dim=1)
        out = self.conv(x)
        return out


class AE(nn.Module):
    def __init__(self, ch):  # 新增参数：inSA的通道数
        super(AE, self).__init__()
        # 传入sa_in_channels，确保sa_reduce层的输入通道数正确
        self.SA = SpatialAttention(in_channels=ch)
        self.CA = ChannelAttention(ch)

    def forward(self, inx, inSA=0):
        x = self.CA(inx, inSA)
        # x = self.CA(inx)
        out = self.SA(x, inSA) * x + x  # inx
        return out


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, inSA=0):
        # 初始化输出为与max_pool(x)同形状的零张量
        out = torch.zeros_like(self.max_pool(x))  # [B, C, 1, 1]

        if torch.is_tensor(inSA):
            # 1. 对inSA进行空间压缩，得到通道维度的统计量
            sa_avg = self.avg_pool(inSA)  # [B, C, 1, 1]（利用inSA的通道信息）
            # 2. 通过MLP生成通道注意力权重
            sa_att = self.fc2(self.relu1(self.fc1(sa_avg)))  # [B, C, 1, 1]
            out = out + sa_att

        # 3. 融合原始特征的max池化通道注意力
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))  # [B, C, 1, 1]
        out = out + max_out

        # 4. 应用注意力并残差连接（维度匹配）
        xout = self.sigmoid(out) * x + x
        return xout


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=3, in_channels=1):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.conv2 = nn.Conv2d(1, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()
        self.sa_reduce = nn.Conv2d(
            in_channels=in_channels,
            out_channels=1,
            kernel_size=1,
            bias=False
        )

    def forward(self, x, inSA=0):
        # avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        if torch.is_tensor(inSA):
            # 仅当inSA是张量时，才处理尺寸和通道
            inSA = F.interpolate(inSA, size=x.shape[2:], mode='bilinear', align_corners=False)
            inSA = self.sa_reduce(inSA)
            x = torch.cat((max_out, inSA), dim=1)  # 拼接为2通道 [B, 2, H, W]
            x = self.conv1(x)
        else:
            # 当inSA不是张量（如0），仅用max_out单通道输入
            x = self.conv2(max_out)
        return self.sigmoid(x)


class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False, groups=groups)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class PositionEmbeddingRandom(nn.Module):
    """
    Positional encoding using random spatial frequencies.
    """

    def __init__(self, num_pos_feats: int = 64, scale: Optional[float] = None) -> None:
        super().__init__()
        if scale is None or scale <= 0.0:
            scale = 1.0
        self.register_buffer(
            "positional_encoding_gaussian_matrix",
            scale * torch.randn((2, num_pos_feats)),
        )

    def _pe_encoding(self, coords: torch.Tensor) -> torch.Tensor:
        """Positionally encode points that are normalized to [0,1]."""
        # assuming coords are in [0, 1]^2 square and have d_1 x ... x d_n x 2 shape
        coords = 2 * coords - 1
        coords = coords @ self.positional_encoding_gaussian_matrix
        coords = 2 * np.pi * coords
        # outputs d_1 x ... x d_n x C shape
        return torch.cat([torch.sin(coords), torch.cos(coords)], dim=-1)

    def forward(self, size: Tuple[int, int]) -> torch.Tensor:
        """Generate positional encoding for a grid of the specified size."""
        h, w = size
        device: Any = self.positional_encoding_gaussian_matrix.device
        grid = torch.ones((h, w), device=device, dtype=torch.float32)
        y_embed = grid.cumsum(dim=0) - 0.5
        x_embed = grid.cumsum(dim=1) - 0.5
        y_embed = y_embed / h
        x_embed = x_embed / w

        pe = self._pe_encoding(torch.stack([x_embed, y_embed], dim=-1))
        return pe.permute(2, 0, 1)  # C x H x W

    def forward_with_coords(
            self, coords_input: torch.Tensor, image_size: Tuple[int, int]
    ) -> torch.Tensor:
        """Positionally encode points that are not normalized to [0,1]."""
        coords = coords_input.clone()
        coords[:, :, 0] = coords[:, :, 0] / image_size[1]
        coords[:, :, 1] = coords[:, :, 1] / image_size[0]
        return self._pe_encoding(coords.to(torch.float))  # B x N x C


def weight_init(module):
    for n, m in module.named_children():
        print('initialize: ' + n)
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, (nn.BatchNorm2d, nn.InstanceNorm2d)):
            nn.init.ones_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Sequential):
            weight_init(m)
        elif isinstance(m, nn.ReLU):
            pass
        else:
            m.initialize()














