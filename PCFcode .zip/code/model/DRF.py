import torch
import torch.nn as nn
# from einops import rearrange, repeat
import math
import torch.nn.functional as F

import numpy as np


class DRM(nn.Module):
    def __init__(self, in_channels_B, in_channels_T, channel, layers=5):
        super(DRM, self).__init__()
        total_in = in_channels_B + in_channels_T  # 拼接后通道数
        convs = [nn.Conv2d(total_in, channel, kernel_size=1),
                 nn.BatchNorm2d(channel),
                 nn.LeakyReLU(negative_slope=0.2, inplace=True)]
        convs.append(DRG(default_conv, channel, kernel_size=3, reduction=16, n_resblocks=layers))
        convs.append(nn.Conv2d(channel, channel, kernel_size=1))
        self.mapping = nn.Sequential(*convs)

    def forward(self, B, T):
        x = torch.cat([B, T], dim=1)
        # x = B + T
        D = self.mapping(x)
        return D


class CA(nn.Module):
    def __init__(self, in_planes=32, ratio=16):
        super(CA, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc = nn.Sequential(nn.Conv2d(in_planes, in_planes // 16, 1, bias=True),
                                nn.ReLU(),
                                nn.Conv2d(in_planes // 16, in_planes, 1, bias=True))
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return x * self.sigmoid(out)


class DSA(nn.Module):
    def __init__(self, in_channels=32, kernel_size=3):
        super().__init__()
        self.kernel_size = kernel_size
        self.kernel_generator = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),  # [B, C, 1, 1]
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(in_channels, kernel_size ** 2, kernel_size=1)  # [B, k*k, 1, 1]
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        B, C, H, W = x.shape

        # 1. 每个样本生成一个动态卷积核 [B, k*k, 1, 1] → [B, 1, k, k]
        kernels = self.kernel_generator(x).view(B, 1, self.kernel_size, self.kernel_size)
        # 2. 对每个样本取通道平均 [B, 1, H, W]
        x_mean = x.mean(dim=1, keepdim=True)
        # 3. reshape 成 grouped convolution 所需格式
        x_mean = x_mean.view(1, B, H, W)  # → [1, B, H, W]
        kernels = kernels.view(B, 1, self.kernel_size, self.kernel_size)  # [B, 1, k, k]
        # 4. 执行 grouped convolution，每个 kernel 只作用于对应的样本
        att = F.conv2d(
            x_mean,
            weight=kernels,
            padding=self.kernel_size // 2,
            groups=B
        )
        # 5. reshape 回原格式 + sigmoid
        att = att.view(B, 1, H, W)
        att = self.sigmoid(att)
        # 6. 应用注意力图
        return x * att


class RAB(nn.Module):
    def __init__(
            self, conv, n_feat, kernel_size, reduction,
            bias=True, bn=False, act=nn.ReLU(True), res_scale=1):

        super(RAB, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)

        modules_body.append(CA(in_planes=n_feat))
        modules_body.append(DSA(in_channels=n_feat))
        # modules_body.append(CA())
        # modules_body.append(DSA())
        self.body = nn.Sequential(*modules_body)
        self.res_scale = res_scale

    def forward(self, x):
        res = self.body(x)
        res += x
        return res


# Residual Group (RG)
class DRG(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction, n_resblocks):
        super(DRG, self).__init__()
        modules_body = []
        modules_body = [
            RAB(
                conv, n_feat, kernel_size, reduction, bias=True, bn=True,
                act=nn.LeakyReLU(negative_slope=0.2, inplace=True), res_scale=1) \
            for _ in range(n_resblocks)]
        modules_body.append(conv(n_feat, n_feat, kernel_size))
        self.body = nn.Sequential(*modules_body)

    def forward(self, x):
        res = self.body(x)
        res += x
        return res


def default_conv(in_channels, out_channels, kernel_size, bias=True):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size,
        padding=(kernel_size // 2), bias=bias)

# if __name__ == "__main__":
#     B = torch.randn(2, 512, 64, 64)
#     T = torch.randn(2, 256, 64, 64)
#     model = DRM(in_channels_B=512, in_channels_T=256, out_channels=32, layers=3)
#     out = model(B, T)
#     print(f"输入 B: {B.shape}, T: {T.shape}")
#     print(f"输出 D: {out.shape}")
#     print("✅ 拼接版模块运行成功！")